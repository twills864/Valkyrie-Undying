﻿using LogUtilAssets.Util;
using System;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace LogUtilAssets
{
    public static partial class LogUtil
    {
        internal partial class UnityStackFrameLine : ParsedText
        {
            /// <summary>
            /// Example: Assets.Bullet.BasicBullet:Init() (at Assets/Bullet/BasicBullet.cs:41)
            /// </summary>
            private string Line => Source;

            /// <summary>
            /// <para>The left-side method signature portion of the represented Unity stack trace line.</para>
            /// <para>Example: Assets.Util.DebugUtil:LogCurrentLine()</para>
            /// </summary>
            private UnityMethodInfo Method { get; set; }

            /// <summary>
            /// <para>The right-side source file portion of the represented Unity stack trace line.</para>
            /// <para>Example: (at Assets\Util\StaticUtil\DebugUtil.cs:42)</para>
            /// </summary>
            private UnityFileInfo File { get; set; }

            /// <summary>
            /// <para>The represented method name and trailing parentheses.</para>
            /// <para>Example: Init()</para>
            /// </summary>
            public string MethodSignature => Method.Method;

            /// <summary>
            /// <para>Formats the represented method signature to resemble IDE syntax coloring, and appends the specified line number.</para>
            /// <para>Example: &gt;color=#5CEFD1&lt;BasicBullet&gt;/color&lt;.&gt;color=white&lt;Init() 32&gt;/color&lt;</para>
            /// </summary>
            /// <param name="lineNumber">The line number to append.</param>
            public string FormattedMethodSignature => Method.GetFormattedMethodSignature(File.LineNumber);

            /// <summary>
            /// <para>The represented line number.</para>
            /// <para>Example: 32</para>
            /// </summary>
            /// <return>The represented line number.</return>
            public string LineNumber => File.LineNumber;

            /// <summary>
            /// <para>Represents a single line in a Unity stack trace, called using StackTraceUtility.ExtractStackTrace()</para>
            /// <para>Example: Assets.Util.DebugUtil:LogCurrentLine() (at Assets\Util\StaticUtil\DebugUtil.cs:42)</para>
            /// </summary>
            /// <param name="source">The represented line from the Unity stack trace.</param>
            public UnityStackFrameLine(string source) : base(source)
            {
            }

            protected override void ParseSource()
            {
                int FirstSpaceIndex = Line.IndexOf(' ');
                string methodSource = Line.Substring(0, FirstSpaceIndex);
                string fileSource = Line.Substring(FirstSpaceIndex + 1);

                Method = new UnityMethodInfo(methodSource);
                File = new UnityFileInfo(fileSource);
            }

            /// <summary>
            /// <para>Generates a hyperlink to the represented line of the represented source file.</para>
            /// <para>Example: &lt;a href="Assets\Bullet\BasicBullet.cs" line="32"&gt;(<paramref name="text"/>)&lt;/a&gt;</para>
            /// </summary>
            /// <param name="text">The text to display in the link.</param>
            public string Hyperlink(string text) => File.Hyperlink(text);

            /// <summary>
            /// <para>Generates a formatted hyperlink to the represented line of the represented source file.</para>
            /// <para>Example: &lt;color=#5CEFD1&gt;BasicBullet&lt;/color&gt;.&lt;color=white&gt;Init() 32&lt;/color&gt; &lt;b&gt;&lt;i&gt;&lt;color=white&gt;&lt;a href="Assets\Bullet\BasicBullet.cs" line="32"&gt;(at Assets\Bullet\BasicBullet.cs:32)&lt;/a&gt;&lt;/color&gt;&lt;/i&gt;&lt;/b&gt;</para>
            /// </summary>
            public string ToFormattedString()
            {
                string link = Hyperlink(File.FullInfo);
                string ret = $"{FormattedMethodSignature} <b><i><color={ColorLink}>{link}</color></i></b>";
                return ret;
            }

            /// <summary>
            /// Example: BasicBullet.Init() (at Assets\Bullet\BasicBullet.cs:32)
            /// </summary>
            public override string ToString()
            {
                string ret = $"{Method.Method} {File.FullInfo}";
                return ret;
            }

            /// <summary>
            /// Formats StackTraceUtility.ExtractStackTrace() to include syntax formatting
            /// and abbreviated stack trace information.
            /// </summary>
            /// <param name="currentFrame">The stack frame object that represents the frame that called this method.</param>
            public static string CustomFormattedStackTrace(out UnityStackFrameLine currentFrame)
            {
                // Only log lines from our code
                const string FirstValidPrefix = "Assets";

                string stackTrace = StackTraceUtility.ExtractStackTrace();

                var stackFrame = stackTrace
                    .Split(new string[] { Separator }, StringSplitOptions.RemoveEmptyEntries)
                    .Skip(1) // Skip current method
                    .SkipWhile(x => !x.StartsWith(FirstValidPrefix))
                    .Select(x => new UnityStackFrameLine(x))
                    .ToList();

                var stackFrameStrList = stackFrame.Select(x => x.ToFormattedString()).ToList();

                currentFrame = stackFrame.First();
                string ret = String.Join(Separator, stackFrameStrList);
                return ret;
            }
        }
    }
}
