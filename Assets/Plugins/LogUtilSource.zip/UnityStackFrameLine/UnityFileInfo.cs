﻿using LogUtilAssets.Util;
using System;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace LogUtilAssets
{
    public static partial class LogUtil
    {
        internal partial class UnityStackFrameLine : ParsedText
        {
            internal class UnityFileInfo : ParsedText
            {
                /// <summary>
                /// <para>The full represented file information.</para>
                /// <para>Example: (at Assets\Util\StaticUtil\DebugUtil.cs:42)</para>
                /// </summary>
                public string FullInfo => Source;

                /// <summary>
                /// <para>The represented file name.</para>
                /// <para>Example: BasicBullet.cs</para>
                /// </summary>
                public string FileName { get; private set; }

                /// <summary>
                /// <para>The represented line number.</para>
                /// <para>Example: 32</para>
                /// </summary>
                public string LineNumber { get; private set; }

                /// <summary>
                /// <para>The represented hyperlink URL.</para>
                /// <para>Example: Assets\Bullet\BasicBullet.cs</para>
                /// </summary>
                public string HyperlinkUrl { get; private set; }

                /// <summary>
                /// <para>Represents the right-side source file portion of the parent UnityStackFrameLine.</para>
                /// <para>Example: (at Assets\Util\StaticUtil\DebugUtil.cs:42)</para>
                /// </summary>
                /// <param name="source">The represented method portion of the parent UnityStackFrameLine</param>
                public UnityFileInfo(string source) : base(source)
                {
                }

                protected override void ParseSource()
                {
                    int lastSlash = Source.LastIndexOf('\\');
                    int colon = Source.IndexOf(':');
                    int lastParenthesis = Source.LastIndexOf(')');
                    int firstSpace = Source.IndexOf(' ');

                    FileName = TextBetween(lastSlash, colon);
                    LineNumber = TextBetween(colon, lastParenthesis);
                    HyperlinkUrl = TextBetween(firstSpace, colon);
                }

                /// <summary>
                /// <para>Formats the abbreviated representation of the file information.</para>
                /// <para>Example: &gt;b&lt;BasicBullet.cs:32&gt;/b&lt;</para>
                /// </summary>
                public string FormattedFileInfo => $"<b>{ToString()}</b>";

                /// <summary>
                /// <para>Generates a hyperlink to the represented line of the represented source file.</para>
                /// <para>Example: &lt;a href="Assets\Bullet\BasicBullet.cs" line="32"&gt;(<paramref name="text"/>)&lt;/a&gt;</para>
                /// </summary>
                /// <param name="text">The text to display in the link.</param>
                public string Hyperlink(string text)
                {
                    string ret = $"<a href=\"{HyperlinkUrl}\" line=\"{LineNumber}\">{text}</a>";
                    return ret;
                }

                /// <summary>
                /// Example: BasicBullet.cs:32
                /// </summary>
                public override string ToString()
                {
                    string ret = $"{FileName}:{LineNumber}";
                    return ret;
                }
            }
        }
    }
}
