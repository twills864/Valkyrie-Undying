﻿using LogUtilAssets.Util;
using System;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace LogUtilAssets
{
    public static partial class LogUtil
    {
        internal partial class UnityStackFrameLine : ParsedText
        {
            internal class UnityMethodInfo : ParsedText
            {
                /// <summary>
                /// <para>The full represented method signature.</para>
                /// <para>Example: Assets.Util.DebugUtil:LogCurrentLine()</para>
                /// </summary>
                public string FullMethodSignature => Source;

                /// <summary>
                /// <para>The represented class name.</para>
                /// <para>Example: BasicBullet</para>
                /// </summary>
                public string Class { get; private set; }

                /// <summary>
                /// <para>The represented method name and trailing parentheses.</para>
                /// <para>Example: Init()</para>
                /// </summary>
                public string Method { get; private set; }

                /// <summary>
                /// <para>Represents the left-side method signature portion of the parent UnityStackFrameLine.</para>
                /// <para>Example: Assets.Util.DebugUtil:LogCurrentLine()</para>
                /// </summary>
                /// <param name="source">The represented method signature portion of the parent UnityStackFrameLine</param>
                public UnityMethodInfo(string source) : base(source)
                {
                }

                protected override void ParseSource()
                {
                    int colonIndex = FullMethodSignature.IndexOf(':');
                    int lastPeriodIndex = FullMethodSignature.LastIndexOf('.');

                    Class = TextBetween(lastPeriodIndex, colonIndex);
                    Method = TextAfter(colonIndex);
                }

                /// <summary>
                /// <para>Formats the represented method signature to resemble IDE syntax coloring, and appends the specified line number.</para>
                /// <para>Example: &gt;color=#5CEFD1&lt;BasicBullet&gt;/color&lt;.&gt;color=white&lt;Init() 32&gt;/color&lt;</para>
                /// </summary>
                /// <param name="lineNumber">The line number to append.</param>
                public string GetFormattedMethodSignature(string lineNumber)
                {
                    string ret = $"<color={ColorClassName}>{Class}</color>.<color={ColorMethodName}>{Method} {lineNumber}</color>";
                    return ret;
                }

                /// <summary>
                /// Example: BasicBullet.Init()
                /// </summary>
                public override string ToString()
                {
                    string ret = $"{Class}.{Method}";
                    return ret;
                }
            }
        }
    }
}
