﻿using LogUtilAssets.Util;
using LogUtilAssets.Util.StaticUtil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace LogUtilAssets
{
    /// <summary>
    /// <para>Provides several utility methods for printing formatted messages to the Unity debug console.</para>
    /// <para>All annotations are based heavily on the annotations provided for the Debug.Log() method/</para>
    /// </summary>
    public static partial class LogUtil
    {
        private static readonly string LoggerPrefix = typeof(LogUtil).ToString();
        private const string Separator = "\n";

        public static string ColorMessage = "white";
        public static string ColorContextMessageDefault = "lime";
        public static string ColorClassName = "#5CEFD1"; // "#4EC9B0"
        public static string ColorMethodName = "white";
        public static string ColorLink = "white";
        public static string ColorPairKey = "yellow"; // "#FFB520";
        public static string ColorPairValue = "cyan";

        // Rich Text Guide
        // https://docs.unity3d.com/Packages/com.unity.ugui@1.0/manual/StyledText.html
        /// <summary>
        /// <para></para>
        /// <para>Example: &gt;color=yellow&lt;Warning!&gt;/color&lt;</para>
        /// </summary>
        private static string ColorText(string color, object text)
        {
            return $"<color={color}>{text}</color>";
        }

        #region Log

        /// <summary>
        /// Logs a default blank value to the Unity Console.
        /// </summary>
        public static void Log() => Log(message: "-");

        /// <summary>
        /// Logs a component to the Unity Console and automatically sets the log context.
        /// </summary>
        /// <param name="component">The component to log.</param>
        public static void Log<T>(T component) where T : Component => Log(component, component);

        /// <summary>
        /// Logs a message to the Unity Console.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for display.</param>
        public static void Log(object message)
        {
            string formattedMessage = FormatMessage(message);
            LogFormattedMessage(formattedMessage);
        }

        /// <summary>
        /// Logs a message to the Unity Console.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void Log(object message, Component context)
        {
            Log(message, context, ColorContextMessageDefault);
        }

        /// <summary>
        /// Logs a message to the Unity Console.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        public static void Log(object message, Component context, string contextColor)
        {
            string formattedMessage = FormatMessage(message);
            string contextFormat = AddContextFormat(formattedMessage, context, contextColor);
            LogFormattedMessage(contextFormat, context);
        }

        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        public static void Log(Expression<Func<object>> expression)
        {
            var kvp = LambdaUtil.GetMemberInfo(expression);
            string formattedPair = FormatMemberInfo(kvp);

            LogFormattedMessage(formattedPair);
        }

        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void Log(Expression<Func<object>> expression, Component context)
        {
            Log(expression, context, ColorContextMessageDefault);
        }

        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        public static void Log(Expression<Func<object>> expression, Component context, string contextColor)
        {
            var kvp = LambdaUtil.GetMemberInfo(expression);
            string formattedPair = FormatMemberInfo(kvp);
            string contextFormat = AddContextFormat(formattedPair, context, contextColor);

            LogFormattedMessage(contextFormat, context);
        }


        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="source">Object to which the message applies.</param>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        public static void Log<T>(T source, Expression<Func<T, object>> expression) where T : Component
        {
            Log(source, expression, ColorContextMessageDefault);
        }

        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="source">Object to which the message applies.</param>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        public static void Log<T>(T source, Expression<Func<T, object>> expression, string contextColor) where T : Component
        {
            var kvp = LambdaUtil.GetMemberInfo(source, expression);
            string formattedPair = FormatMemberInfo(kvp);
            string contextFormat = AddContextFormat(formattedPair, source, contextColor);

            LogFormattedMessage(contextFormat, source);
        }

        /// <summary>
        /// Logs the names and values of an arbitrary number of expressions to the Unity Console.
        /// </summary>
        /// <param name="source">Object to which the message applies.</param>
        /// <param name="expression">Expressions to be converted to string representations for display.</param>
        public static void Log<T>(T source, params Expression<Func<T, object>>[] expressions) where T : Component
        {
            Log(source, ColorContextMessageDefault, expressions);
        }

        /// <summary>
        /// Logs the names and values of an arbitrary number of expressions to the Unity Console.
        /// </summary>
        /// <param name="source">Object to which the message applies.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        /// <param name="expression">Expressions to be converted to string representations for display.</param>
        public static void Log<T>(T source, string contextColor, params Expression<Func<T, object>>[] expressions) where T : Component
        {
            var kvps = expressions.Select(x => LambdaUtil.GetMemberInfo(source, x));
            string formattedPairs = FormatMemberInfo(kvps);
            string contextFormat = AddContextFormat(formattedPairs, source, contextColor);

            LogFormattedMessage(contextFormat, source);
        }

        /// <summary>
        /// Logs an already-formatted message to the Unity Console, placing the
        /// method name and line number of the call on the second line,
        /// followed finally by a formatted full stack trace.
        /// </summary>
        /// <param name="formattedMessage">String or object to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        private static void LogFormattedMessage(string formattedMessage, Component context = null)
        {
            string stackTrace = UnityStackFrameLine.CustomFormattedStackTrace(out var currentFrame);
            string currentMethod = currentFrame.FormattedMethodSignature; // UnityStackFrameLine.FormatMethodName(currentMethod);

            string log = $"{formattedMessage}\n{currentMethod}\n\n{stackTrace}\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
            Debug.Log(log, context);
            //Debug.unityLogger.Log(LogType.Log, message: log, context: context);
        }

        #endregion Log

        #region Format Messages

        private static string PairStart => ColorText(ColorMessage, "{ ");
        private static string PairSeparator => ColorText(ColorMessage, ": ");
        private static string PairEnd => ColorText(ColorMessage, " }");
        private static string PairListSeparator => ColorText(ColorMessage, "; ");

        /// <summary>
        /// Applies formatting to the given message.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for formatting.</param>
        private static string FormatMessage(object message)
        {
            string ret;

            if (!ReflectionUtil.IsAnonymousType(message.GetType()))
                ret = $"<b>{ColorText(ColorMessage, message)}</b>";
            else
                ret = $"<b>{ExplodeObject(message)}</b>";
            return ret;
        }

        /// <summary>
        /// Applies formatting to the given KeyValuePair.
        /// </summary>
        /// <param name="pair">Pair of values to be converted to string for formatting.</param>
        private static string FormatMemberInfoPair<T>(KeyValuePair<T, object> pair)
        {
            string key = ColorText(ColorPairKey, pair.Key);
            string value = ColorText(ColorPairValue, pair.Value);

            string ret = $"{key}{PairSeparator}{value}";
            return ret;

        }

        /// <summary>
        /// Applies final console formatting to the given KeyValuePair.
        /// </summary>
        /// <param name="pair">Pair of values to be converted to string for formatting.</param>
        private static string FormatMemberInfo<T>(KeyValuePair<T, object> pair)
        {
            string formattedPair = FormatMemberInfoPair(pair);
            var ret = $"<b>{PairStart}{formattedPair}{PairEnd}</b>";
            return ret;
        }

        /// <summary>
        /// Applies final console formatting to an arbitrary numbers of KeyValuePairs.
        /// </summary>
        /// <param name="pairs">Pairs of values to be converted to strings for formatting.</param>
        private static string FormatMemberInfo<T>(IEnumerable<KeyValuePair<T, object>> pairs)
        {
            return FormatMemberInfo(pairs.ToArray());
        }

        /// <summary>
        /// Applies final console formatting to an arbitrary numbers of KeyValuePairs.
        /// </summary>
        /// <param name="pairs">Pairs of values to be converted to strings for formatting.</param>
        private static string FormatMemberInfo<T>(params KeyValuePair<T, object>[] pairs)
        {
            var formattedPairs = pairs.Select(x => FormatMemberInfoPair(x));
            var join = String.Join(PairListSeparator, formattedPairs);
            var ret = $"<b>{PairStart}{join}{PairEnd}</b>";
            return ret;
        }

        #endregion Format Messages

        #region Context Formatting

        /// <summary>
        /// Applies context message formatting to the given message.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for formatting.</param>
        /// <param name="context">Object to which the message applies.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        private static string AddContextFormat(object message, Component context, string contextColor)
        {
            string component = ComponentTypeTag(context);
            string start = ColorText(contextColor, component);
            string ret = $"{start}{message}";
            return ret;
        }

        /// <summary>
        /// Creates a tag out of a given component to apply at the beginning of a debug log message
        /// for which this component is the context.
        /// </summary>
        /// <param name="context">Object to which the message applies.</param>
        /// <returns>The type of the context, surrounded by brackets, followed by a space.</returns>
        public static string ComponentTypeTag(Component context)
        {
            var type = context.GetType().Name;
            var ret = $"<size=10>[{type}]</size> ";
            return ret;
        }

        /// <summary>
        /// Creates a shortened version of the standard Component.ToString() method
        /// in which the namespace of the type of the object is removed.
        /// </summary>
        /// <param name="component">Component to be converted to string representation for display.</param>
        /// <returns>{Name of object} ({Type of object})</returns>
        public static string ShortenedComponentString(Component component)
        {
            var type = component.GetType().Name;
            var gameObject = component.gameObject.name;
            var ret = $"{gameObject} ({type})";
            return ret;
        }

        #endregion Context Formatting

        #region Explode

        /// <summary>
        /// Converts an object to a string that displays the names and values of the properties of the object.
        /// </summary>
        /// <param name="toExplode">Object to be converted to property-based string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        /// <returns><para>A string representing the properties of an object, in the form:</para>
        /// <para>{ prop1: value1, prop2: value2, ... }</para></returns>
        private static string ExplodeObject(object toExplode)
        {
            var props = toExplode.GetType().GetProperties();
            var propValues = props.Select(x => ReflectionUtil.GetMemberInfo(x, toExplode));

            string ret = FormatMemberInfo(propValues);
            return ret;
        }

        /// <summary>
        /// Logs an object to the Unity Console on a property-by-property basis.
        /// </summary>
        /// <param name="toExplode">Object to be converted to property-based string representation for display.</param>
        public static void LogExplode(object toExplode)
        {
            string exploded = ExplodeObject(toExplode);
            LogFormattedMessage(exploded);
        }

        /// <summary>
        /// Logs an object to the Unity Console on a property-by-property basis.
        /// </summary>
        /// <param name="toExplode">Object to be converted to property-based string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void LogExplode(object toExplode, Component context)
        {
            LogExplode(toExplode, context, ColorContextMessageDefault);
        }

        /// <summary>
        /// Logs an object to the Unity Console on a property-by-property basis.
        /// </summary>
        /// <param name="toExplode">Object to be converted to property-based string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        /// <param name="contextColor">The color to apply to the context tag.</param>
        public static void LogExplode(object toExplode, Component context, string contextColor)
        {
            string exploded = ExplodeObject(toExplode);
            string contextFormat = AddContextFormat(exploded, context, contextColor);
            LogFormattedMessage(contextFormat, context);
        }

        #endregion Explode

        #region Stack Tracing

        /// <summary>
        /// Returns the name of the current method, followed by the line in the source file
        /// in which the call occurs.
        /// </summary>
        /// <returns>{Method name}() {Line number}</returns>
        public static string CurrentMethod
        {
            get
            {
                return GetParentMethod(0);
            }
        }

        /// <summary>
        /// Returns the name of the parent method a specified number of frames up the call stack,
        /// followed by the line in the respective source file in which the call occurs.
        /// </summary>
        /// <returns>{Method name}() {Line number}</returns>
        public static string GetParentMethod(int framesToSkip = 1)
        {
            string source = StackTraceUtility.ExtractStackTrace();

            var stackFrame = source
                .Split(new string[] { Separator }, StringSplitOptions.RemoveEmptyEntries)
                .SkipWhile(x => x.StartsWith(LoggerPrefix))
                .Skip(framesToSkip)
                .Take(1)
                .Select(x => new UnityStackFrameLine(x))
                .First();

            string methodName = stackFrame.MethodSignature;
            string lineNumber = stackFrame.LineNumber;
            string ret = $"{methodName} {lineNumber}";
            return ret;
        }

        #endregion Stack Tracing

        #region Rainbow

        public const string RainbowRed = "#FF2020";
        public const string RainbowOrange = "#FFB520";
        public const string RainbowYellow = "yellow";
        public const string RainbowGreen = "lime";
        public const string RainbowBlue = "cyan";
        public const string RainbowPurple = "#FF40FF";
        /// <summary>
        /// Logs a message to the Unity Console, printing each character of the message
        /// in the next color of the rainbow.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for display.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void Rainbow(object message, Component context = null)
        {
            CircularSelector<string> colors = new CircularSelector<string>()
            {
                RainbowRed,
                RainbowOrange,
                RainbowYellow,
                RainbowGreen,
                RainbowBlue,
                RainbowPurple
            };

            var sb = new StringBuilder();

            string _message = message.ToString();
            for(int i = 0; i < _message.Length; i++)
            {
                char c = _message[i];
                if (!Char.IsWhiteSpace(c))
                {
                    sb.Append("<color=").Append(colors.GetAndIncrement()).Append(">")
                        .Append(_message[i]).Append("</color>");
                }
                else
                {
                    sb.Append(c);
                }
            }

            string log = sb.ToString();
            Debug.Log(log, context);
        }

        #endregion Rainbow
    }
}
