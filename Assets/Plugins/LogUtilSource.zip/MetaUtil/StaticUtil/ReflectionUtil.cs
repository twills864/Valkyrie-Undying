﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace LogUtilAssets.Util.StaticUtil
{
    internal class ReflectionUtil
    {
        /// <summary>
        /// Stores the cached results of previous calls to IsAnonymousType()
        /// </summary>
        public static Dictionary<Type, bool> PrecalculatedTypes = new Dictionary<Type, bool>();

        /// <summary>
        /// Returns a boolean value the represents whether or not a given object is an anonymously-typed object.
        /// </summary>
        /// <param name="source">The object to examine.</param>
        /// <returns>True if the object has an anonymous type; False otherwise.</returns>
        public static bool IsAnonymousType(object source) => IsAnonymousType(source.GetType());

        /// <summary>
        /// Returns a boolean value the represents whether or not a given type is anonymous.
        /// </summary>
        /// <param name="type">The type to examine.</param>
        /// <returns>True if the type is an anonymous type; False otherwise.</returns>
        public static bool IsAnonymousType(Type type)
        {
            if (!PrecalculatedTypes.TryGetValue(type, out bool ret))
                ret = PrecalculatedTypes[type] = CalculateAnonymousTypeStatus(type);

            return ret;
        }

        // Code adapted from:
        // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/ViewEngines/Extensions.cs
        /// <summary>
        /// <para>Uses reflection to calculate whether or not an give type is anonymous.</para>
        /// <para>Uses incomplete checks that are known to work in the context of this game.</para>
        /// </summary>
        /// <param name="type">The type to examine.</param>
        /// <returns>True if the type is an anonymous type; False otherwise.</returns>
        private static bool CalculateAnonymousTypeStatus(Type type)
        {
            bool ret = type.Name.StartsWith("<>", StringComparison.OrdinalIgnoreCase)
                && type.Name.Contains("AnonymousType");
            return ret;
        }

        // Code adapted from:
        // https://github.com/NancyFx/Nancy/blob/master/src/Nancy/ViewEngines/Extensions.cs
        /// <summary>
        /// Uses reflection to calculate whether or not an give type is anonymous.
        /// </summary>
        /// <param name="type">The type to examine.</param>
        /// <returns>True if the type is an anonymous type; False otherwise.</returns>
        private static bool CalculateAnonymousTypeStatusComprehensively(Type type)
        {
            TypeInfo typeInfo = type.GetTypeInfo();
            bool ret = typeInfo.IsGenericType
                && (typeInfo.Attributes & TypeAttributes.NotPublic) == TypeAttributes.NotPublic
                && type.Name.StartsWith("<>", StringComparison.OrdinalIgnoreCase) // || type.Name.StartsWith("VB$", StringComparison.OrdinalIgnoreCase))
                && type.Name.Contains("AnonymousType") // || type.Name.Contains("AnonType"))
                && typeInfo.GetCustomAttributes(typeof(CompilerGeneratedAttribute)).Any();

            return ret;
        }

        /// <summary>
        /// Returns the name and value of a given property with a given source.
        /// </summary>
        /// <param name="propInfo">The PropertyInfo to examine.</param>
        /// <param name="source">The source of the PropertyInfo from which to retrieve the value of the property.</param>
        /// <returns>A key value pair in which the key is the name of the given expression,
        /// and the value is the value of the given expression.</returns>
        public static KeyValuePair<object, object> GetMemberInfo(PropertyInfo propInfo, object source)
        {
            var ret = new KeyValuePair<object, object>(propInfo.Name, propInfo.GetValue(source));
            return ret;
        }
    }
}
