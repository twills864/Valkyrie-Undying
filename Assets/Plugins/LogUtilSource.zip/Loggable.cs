﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace LogUtilAssets
{
    public class Loggable : MonoBehaviour
    {
        /// <summary>
        /// The color to be used as this component's tag color.
        /// </summary>
        public virtual string LogTagColor { get => LogUtil.ColorContextMessageDefault; }

        /// <summary>
        /// <para>Logs the name and value of an expression to the Unity Console.</para>
        /// <para>Designed to be called in a subclass-specific overload of log()</para>
        /// </summary>
        /// <param name="expressions">Expression to be converted to string representation for display.</param>
        /// <example>
        /// <code>
        /// public void log(Expression<Func<BasicBullet, object>> <paramref name="expressions"/>)
        /// {
        ///     LogExpression(<paramref name="expressions"/>);
        /// }
        /// </code>
        /// </example>
        [Conditional("UNITY_EDITOR")]
        protected void LogExpression<T>(Expression<Func<T, object>>[] expressions) where T : Loggable
        {
            LogUtil.Log<T>((T)this, LogTagColor, expressions);
        }

        /// <summary>
        /// Logs a default value to the Unity Console.
        /// </summary>
        [Conditional("UNITY_EDITOR")]
        public virtual void Log()
        {
            LogUtil.Log(this, this, LogTagColor);
        }

        /// <summary>
        /// Logs a message to the Unity Console.
        /// </summary>
        /// <param name="message">String or object to be converted to string representation for display.</param>
        [Conditional("UNITY_EDITOR")]
        public virtual void Log(object message)
        {
            LogUtil.Log(message, this, LogTagColor);
        }

        /// <summary>
        /// Logs the name and value of an expression to the Unity Console.
        /// </summary>
        /// <param name="expression">Expression to be converted to string representation for display.</param>
        [Conditional("UNITY_EDITOR")]
        public virtual void Log(Expression<Func<object>> expression)
        {
            LogUtil.Log(expression, this, LogTagColor);
        }

        /// <summary>
        /// Logs an object to the Unity Console on a property-by-property basis.
        /// </summary>
        /// <param name="toExplode">Object to be converted to property-based string representation for display.</param>
        [Conditional("UNITY_EDITOR")]
        public virtual void Explode(object toExplode)
        {
            LogUtil.LogExplode(toExplode, this, LogTagColor);
        }
    }
}
